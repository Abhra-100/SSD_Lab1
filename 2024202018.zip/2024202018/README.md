2024202018_q1.sh is the shell script for the first problem.

If we execute this script we will get the output of the first problem.

It uses the grep command and use -E as the option to utilize the and condition over the two patterns in each row on the access.log file.



2024202018_q2.sh is the shell script for the second problem.

If we execute this script we will get the output of the second problem.

It uses the awk command and use ',' as the delimeter and then takes the 4th column values in atemporary variable sum and at the end prints sum on the power_levels.txt file.



