#!/bin/bash
grep -E "POST.*404" access.log